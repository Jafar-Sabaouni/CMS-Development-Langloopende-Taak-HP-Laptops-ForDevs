import * as React from "react"
import { Link } from "gatsby"
import { GatsbyImage, getImage } from "gatsby-plugin-image"
import { graphql } from "gatsby"
import Layout from "../components/layout"
import {gatsbyImage
,ItemContainer}from "./Laptops.module.css"


const Laptops = ({ data: { allWpLaptop: { edges } } }) => {
  return (
    <Layout>
      {edges.map((item) => {
        const Laptop = item.node.laptopMeta;
        const image = getImage(item.node.laptopMeta.picture1.localFile)
        const slug = item.node.slug;
        return (<div className={ItemContainer}>
            <p>{item.node.title}</p>
            
            <GatsbyImage className={gatsbyImage} image={image} alt={item.node.laptopMeta.picture1.altText} />
            <p>{Laptop.price}</p>
            <p>{Laptop.description}</p>
            <Link to={`${slug}`}>
              <p key={item.node.id}> more > </p>
            </Link>

        </div>)

      })}
    </Layout>
  )
}

export const query = graphql`
query{
  allWpLaptop {
    edges {
      node {
        title
        developers {
          nodes {
            name
          }
        }
        laptopMeta {
          cpu
          description
          fieldGroupName
          gpu
          model
          storagetype
          storage
          screensize
          ram
          price
          picture1 {
            localFile {
              childImageSharp {
                gatsbyImageData(placeholder: BLURRED)
              }
            }
            altText
          }
        }
        slug
        id
      }
    }
  }
}


`

export default Laptops