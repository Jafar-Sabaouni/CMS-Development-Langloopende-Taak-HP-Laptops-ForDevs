import * as React from "react"
import { graphql } from "gatsby"
import { GatsbyImage, getImage } from "gatsby-plugin-image"
import Layout from "../../components/layout"

const ArtistPage = ({
  data: {
    wpLaptop: { laptopMeta: laptop },
  },
}) => {
  const image = getImage(laptop.picture1.localFile)

  return (
    <Layout >
      <div>
        <GatsbyImage image={image} alt={laptop.picture1.altText} />
        <p>model: {laptop.model}</p>

      </div>
    </Layout>
  )
}

export const query = graphql`
query MyQuery($slug: String) {
  wpLaptop(slug: { eq: $slug }) {
    laptopMeta {
      cpu
      description
      fieldGroupName
      gpu
      model
      price
      ram
      screensize
      storage
      storagetype
      picture1 {
        localFile {
          childImageSharp {
            gatsbyImageData(placeholder: BLURRED)
          }
        }
        altText
      }
    }
  }
}

`

export default ArtistPage